exports.homeGet = function(req, res)
{
  res.sendfile('./routes/index.html');
};

